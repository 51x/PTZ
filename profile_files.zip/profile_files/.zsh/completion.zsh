autoload -U compinit && compinit                                                                                        
zmodload -i zsh/complist
