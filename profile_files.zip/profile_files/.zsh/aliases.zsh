alias py='python'
alias pl='perl'
